// content.js - SAGE BOT
console.log("🚀 SAGE BOT CONTENT ACTIVE");

// ============================================
// KLIK XPATH
// ============================================
function clickByXPath(xpath) {
  console.log(`🖱️ clickByXPath: ${xpath}`);
  try {
    const result = document.evaluate(
      xpath,
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    );
    const element = result.singleNodeValue;
    
    if (element) {
      const target = element.closest('button') || element.closest('a') || element;
      target.click();
      console.log(`✅ Clicked: ${xpath}`);
      return { success: true };
    } else {
      console.log(`❌ Element not found: ${xpath}`);
      return { success: false, error: 'element_not_found' };
    }
  } catch (e) {
    console.log(`❌ Click error (${xpath}):`, e.message);
    return { success: false, error: e.message };
  }
}

// ============================================
// ISI INPUT
// ============================================
function fillInput(xpath, value) {
  console.log(`📝 fillInput: ${xpath} = ${value}`);
  try {
    const result = document.evaluate(
      xpath,
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    );
    const element = result.singleNodeValue;
    
    if (element) {
      element.focus();
      element.value = value;
      element.dispatchEvent(new Event('input', { bubbles: true }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
      console.log(`✅ Filled: ${xpath} = ${value}`);
      return { success: true };
    } else {
      console.log(`❌ Input not found: ${xpath}`);
      return { success: false, error: 'element_not_found' };
    }
  } catch (e) {
    console.log(`❌ Fill error (${xpath}):`, e.message);
    return { success: false, error: e.message };
  }
}

// ============================================
// CEK APAKAH LOGIN BERHASIL
// ============================================
function checkLoginSuccess() {
  console.log("🔍 Checking login success...");
  
  try {
    const loginForms = document.querySelectorAll('input[type="email"], input[name="username"], input[type="password"]');
    const hasLoginForm = loginForms.length > 0;
    
    const url = window.location.href;
    const isLoginPage = url.includes('login') || url.includes('signin');
    
    const hasDashboard = document.querySelector('[class*="dashboard"], [id*="dashboard"], [class*="workspace"]');
    
    const bodyText = document.body.innerText || '';
    const hasSageMaker = bodyText.includes('SageMaker') || bodyText.includes('Studio Lab');
    const hasRuntime = bodyText.includes('Start runtime') || bodyText.includes('Runtime');
    
    console.log("📊 Cek login result:", { 
      hasLoginForm, 
      isLoginPage, 
      hasDashboard, 
      hasSageMaker,
      hasRuntime,
      url 
    });
    
    if (hasLoginForm && isLoginPage) {
      console.log("❌ Masih di halaman login");
      return { success: false, reason: 'still_on_login' };
    }
    
    if (hasDashboard || hasSageMaker || hasRuntime) {
      console.log("✅ Login berhasil! Halaman utama terdeteksi");
      return { success: true };
    }
    
    if (!isLoginPage && url.includes('studiolab.sagemaker.aws')) {
      console.log("✅ Login berhasil! URL sudah berubah");
      return { success: true };
    }
    
    console.log("⚠️ Tidak yakin login berhasil");
    return { success: false, reason: 'unknown' };
    
  } catch (e) {
    console.log("❌ Error cek login:", e.message);
    return { success: false, reason: 'error', error: e.message };
  }
}

// ============================================
// CEK CAPTCHA
// ============================================
function checkCaptchaActive() {
  console.log("🔍 Checking captcha...");
  
  try {
    const bodyText = document.body.innerText || '';
    if (bodyText.includes('Pilih semua tirai') || 
        bodyText.includes('pilih semua') ||
        bodyText.includes('captcha') ||
        bodyText.includes('verifikasi') ||
        bodyText.includes('konfirmasikan') ||
        bodyText.includes('Konfirmasikan')) {
      console.log("🖼️ CAPTCHA TERDETEKSI! (teks)");
      return { active: true, type: 'text_captcha' };
    }
    
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
      const src = iframe.src || '';
      if (src.includes('captcha') || src.includes('recaptcha') || src.includes('verify')) {
        console.log("🖼️ CAPTCHA IFRAME TERDETEKSI!");
        return { active: true, type: 'iframe_captcha' };
      }
    }
    
    const captchaElements = document.querySelectorAll('[class*="captcha"], [id*="captcha"], [class*="verify"], [class*="challenge"]');
    if (captchaElements.length > 0) {
      console.log("🖼️ ELEMEN CAPTCHA TERDETEKSI!");
      return { active: true, type: 'element_captcha' };
    }
    
    return { active: false };
  } catch (e) {
    console.log("Error cek captcha:", e.message);
    return { active: false };
  }
}

// ============================================
// CEK TOMBOL START RUNTIME
// ============================================
function checkRuntimeButton() {
  console.log("🔍 Checking Start Runtime button...");
  
  try {
    const buttons = document.querySelectorAll('button');
    for (const button of buttons) {
      const text = button.textContent || '';
      if (text.includes('Start runtime') || text.includes('Start')) {
        if (button.disabled) {
          console.log("⏳ Tombol Start Runtime disabled (masih loading)");
          return { started: false, status: 'loading' };
        }
        console.log("⏳ Tombol Start Runtime masih ada");
        return { started: false, status: 'waiting' };
      }
      if (text.includes('Stop') || text.includes('Running') || text.includes('Started')) {
        console.log("✅ Tombol sudah berubah jadi:", text);
        return { started: true, status: 'running' };
      }
    }
  } catch (e) {
    console.log("❌ Error cek tombol:", e.message);
  }
  
  try {
    const bodyText = document.body.innerText || '';
    if (bodyText.includes('Running')) {
      console.log("✅ Teks 'Running' ditemukan");
      return { started: true, status: 'running' };
    }
  } catch (e) {}
  
  try {
    const statusElements = document.querySelectorAll('[class*="status"], [id*="status"]');
    for (const el of statusElements) {
      const text = el.textContent || '';
      if (text.includes('Running') || text.includes('Started')) {
        console.log("✅ Status ditemukan:", text);
        return { started: true, status: 'running' };
      }
    }
  } catch (e) {}
  
  console.log("⏳ Start Runtime belum berubah");
  return { started: false, status: 'not_found' };
}

// ============================================
// MESSAGE LISTENER
// ============================================
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("📩 Content received:", message.action);
  
  if (message.action === 'clickXPath') {
    const result = clickByXPath(message.xpath);
    sendResponse(result);
    return true;
  }
  
  if (message.action === 'fillInput') {
    const result = fillInput(message.xpath, message.value);
    sendResponse(result);
    return true;
  }
  
  if (message.action === 'checkRuntimeButton') {
    const result = checkRuntimeButton();
    sendResponse(result);
    return true;
  }
  
  if (message.action === 'checkLoginSuccess') {
    const result = checkLoginSuccess();
    sendResponse(result);
    return true;
  }
  
  if (message.action === 'checkCaptcha') {
    const result = checkCaptchaActive();
    sendResponse(result);
    return true;
  }
  
  return true;
});
