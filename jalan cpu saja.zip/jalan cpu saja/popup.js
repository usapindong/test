// popup.js - SAGE BOT

let isUpdating = false;

document.addEventListener('DOMContentLoaded', async () => {
  console.log("Popup loaded");
  await loadProxyList();
  await updateStatus();
  await checkBotState();
  
  setInterval(() => {
    if (!isUpdating) updateStatus();
  }, 2000);
});

// ============================================
// CHECK BOT STATE
// ============================================
async function checkBotState() {
  try {
    const status = await browser.runtime.sendMessage({ command: "getStatus" });
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    
    if (status && status.active) {
      startBtn.style.display = 'none';
      stopBtn.style.display = 'block';
    } else {
      startBtn.style.display = 'block';
      stopBtn.style.display = 'none';
    }
  } catch (error) {
    console.error("Check state error:", error);
  }
}

// ============================================
// START BOT
// ============================================
document.getElementById('startBtn').addEventListener('click', async () => {
  console.log("Start button clicked");
  document.getElementById('startBtn').style.display = 'none';
  document.getElementById('stopBtn').style.display = 'block';
  
  await browser.runtime.sendMessage({ command: "startBot" });
  setTimeout(() => updateStatus(), 500);
});

// ============================================
// STOP BOT
// ============================================
document.getElementById('stopBtn').addEventListener('click', async () => {
  console.log("Stop button clicked");
  await browser.runtime.sendMessage({ command: "stopBot" });
  
  document.getElementById('startBtn').style.display = 'block';
  document.getElementById('stopBtn').style.display = 'none';
  
  setTimeout(() => updateStatus(), 500);
});

// ============================================
// SAVE PROXY
// ============================================
document.getElementById('saveProxyBtn').addEventListener('click', async () => {
  const textarea = document.getElementById('proxyPaste');
  const lines = textarea.value.split('\n')
    .map(l => l.trim())
    .filter(l => l && l.length > 0);
  
  if (lines.length === 0) {
    alert('Masukkan proxy dulu! Format: host:port:user:pass');
    return;
  }
  
  await browser.runtime.sendMessage({
    command: "saveProxyList",
    proxies: lines
  });
  
  await loadProxyList();
  textarea.value = '';
  document.getElementById('infoText').innerHTML = `✅ ${lines.length} proxy saved!`;
  setTimeout(() => {
    document.getElementById('infoText').innerHTML = 
      '🔄 Login otomatis dari CSV<br>⏳ Maksimal tunggu 10 menit per akun<br>🗑️ Hapus cookie + tutup tab otomatis';
  }, 3000);
});

// ============================================
// LOAD PROXY LIST
// ============================================
async function loadProxyList() {
  try {
    const response = await browser.runtime.sendMessage({ command: "getProxyList" });
    const proxies = response.proxies || [];
    document.getElementById('proxyCount').innerText = proxies.length;
  } catch (error) {
    console.error("Load proxy error:", error);
  }
}

// ============================================
// UPDATE STATUS
// ============================================
async function updateStatus() {
  try {
    isUpdating = true;
    
    const status = await browser.runtime.sendMessage({ command: "getStatus" });
    const data = await browser.storage.local.get('activeProxy');
    
    const proxyText = document.getElementById('proxyText');
    if (proxyText) {
      if (data.activeProxy) {
        const short = data.activeProxy.split(':').slice(0, 2).join(':');
        proxyText.innerText = short;
      } else {
        proxyText.innerText = 'None';
      }
    }
    
    const accountText = document.getElementById('accountText');
    if (accountText && status) {
      if (status.active) {
        accountText.innerText = `${status.accountIndex + 1}/${status.totalAccounts}`;
      } else {
        accountText.innerText = '0/0';
      }
    }
    
    const statusText = document.getElementById('statusText');
    if (statusText && status) {
      if (status.active) {
        statusText.innerText = '🔄 Running';
        statusText.style.color = '#10b981';
      } else {
        statusText.innerText = '⏹️ Idle';
        statusText.style.color = '#94a3b8';
      }
    }
    
    isUpdating = false;
  } catch (error) {
    console.error("Update status error:", error);
    isUpdating = false;
  }
}

// ============================================
// LISTENER FROM BACKGROUND
// ============================================
browser.runtime.onMessage.addListener((message) => {
  if (message.command === "updateStatus") {
    document.getElementById('infoText').innerHTML = message.text;
  }
  
  if (message.command === "botStopped") {
    document.getElementById('startBtn').style.display = 'block';
    document.getElementById('stopBtn').style.display = 'none';
    setTimeout(() => updateStatus(), 300);
  }
});
