// background.js - SAGE BOT (Login + Runtime + Proxy Rotator)
console.log("🚀 SAGE BOT ACTIVE");

// ============================================
// PROXY LIST (24 PROXY)
// ============================================
const DEFAULT_PROXIES = [
  "82.22.214.219:6071:zlveuxif:q9mmdpelsn6z",
  "82.22.214.253:6105:zlveuxif:q9mmdpelsn6z",
  "82.22.214.26:5878:zlveuxif:q9mmdpelsn6z",
  "82.22.214.13:5865:zlveuxif:q9mmdpelsn6z",
  "82.22.214.52:5904:zlveuxif:q9mmdpelsn6z",
  "82.22.214.205:6057:zlveuxif:q9mmdpelsn6z",
  "82.22.214.116:5968:zlveuxif:q9mmdpelsn6z",
  "82.22.214.27:5879:zlveuxif:q9mmdpelsn6z",
  "82.22.214.234:6086:zlveuxif:q9mmdpelsn6z",
  "82.22.214.86:5938:zlveuxif:q9mmdpelsn6z",
  "82.22.214.149:6001:zlveuxif:q9mmdpelsn6z",
  "82.22.214.87:5939:zlveuxif:q9mmdpelsn6z",
  "82.22.214.193:6045:zlveuxif:q9mmdpelsn6z",
  "82.22.214.120:5972:zlveuxif:q9mmdpelsn6z",
  "82.22.214.209:6061:zlveuxif:q9mmdpelsn6z",
  "82.22.214.28:5880:zlveuxif:q9mmdpelsn6z",
  "82.22.214.69:5921:zlveuxif:q9mmdpelsn6z",
  "82.22.214.98:5950:zlveuxif:q9mmdpelsn6z",
  "82.22.214.11:5863:zlveuxif:q9mmdpelsn6z",
  "82.22.214.147:5999:zlveuxif:q9mmdpelsn6z",
  "82.22.214.199:6051:zlveuxif:q9mmdpelsn6z",
  "82.22.214.92:5944:zlveuxif:q9mmdpelsn6z",
  "82.22.214.176:6028:zlveuxif:q9mmdpelsn6z",
  "82.22.214.59:5911:zlveuxif:q9mmdpelsn6z"
];

// ============================================
// XPath LIST
// ============================================
const XPATHS = {
  loginButton: '//div[2]/button/span',
  username: '(//input[contains(@name,"username")])',
  password: '(//input[contains(@name,"password")])',
  signInButton: '//div[4]/button/span',
  startRuntime: '//span/button',
  extraButton: '//div[2]/div[2]/div/div/div/div/div/button/span',
  projectButton: '//button[contains(text(), "Project")]'
};

// ============================================
// STATE
// ============================================
let botState = {
  active: false,
  proxyIndex: 0,
  proxyList: [],
  accounts: [],
  accountIndex: 0,
  stopRequested: false,
  activeProxy: null
};

// ============================================
// FUNGSI SLEEP
// ============================================
function sleep(ms) {
  return new Promise((resolve, reject) => {
    const interval = setInterval(() => {
      if (botState.stopRequested || !botState.active) {
        clearInterval(interval);
        clearTimeout(timer);
        reject(new Error('Stopped by user'));
      }
    }, 100);
    const timer = setTimeout(() => {
      clearInterval(interval);
      resolve();
    }, ms);
  });
}

function randomDelay() {
  const ms = Math.floor(Math.random() * 5000) + 5000;
  console.log(`⏳ Jeda random: ${(ms/1000).toFixed(1)} detik`);
  return sleep(ms);
}

// ============================================
// FUNGSI UPDATE UI
// ============================================
function updateStatus(text) {
  browser.runtime.sendMessage({ command: "updateStatus", text }).catch(() => {});
}

function updateBadge(text, color) {
  try {
    browser.browserAction.setBadgeText({ text: text || '' });
    if (color) browser.browserAction.setBadgeBackgroundColor({ color });
  } catch (e) {}
}

// ============================================
// PROXY FUNCTIONS
// ============================================
async function setProxy(proxyString) {
  botState.activeProxy = proxyString;
  await browser.storage.local.set({ activeProxy: proxyString });
  console.log(`🔌 Proxy: ${proxyString.split(':').slice(0,2).join(':')}`);
  updateStatus(`🔌 Proxy: ${proxyString.split(':').slice(0,2).join(':')}`);
}

async function clearProxy() {
  botState.activeProxy = null;
  await browser.storage.local.set({ activeProxy: null });
}

// ============================================
// HAPUS COOKIES SAGEMAKER
// ============================================
async function clearSageMakerCookies() {
  try {
    const cookies = await browser.cookies.getAll({
      domain: ".sagemaker.aws"
    });
    
    for (const cookie of cookies) {
      await browser.cookies.remove({
        url: `https://${cookie.domain}${cookie.path}`,
        name: cookie.name
      });
    }
    
    console.log(`🍪 Cleared ${cookies.length} cookies`);
    return cookies.length;
  } catch (e) {
    console.log("Clear cookies error:", e);
    return 0;
  }
}

// ============================================
// BACA CSV
// ============================================
async function loadAccounts() {
  try {
    const response = await fetch(browser.runtime.getURL('accounts.csv'));
    const csvText = await response.text();
    
    const lines = csvText.split('\n').filter(line => line.trim());
    const accounts = [];
    
    for (let i = 1; i < lines.length; i++) {
      const parts = lines[i].split(',').map(s => s.trim());
      if (parts.length >= 2 && parts[0] && parts[1]) {
        accounts.push({
          username: parts[0],
          password: parts[1],
          used: false
        });
      }
    }
    
    console.log(`📋 Loaded ${accounts.length} accounts from CSV`);
    return accounts;
  } catch (e) {
    console.error("Load CSV error:", e);
    return [];
  }
}

// ============================================
// HAPUS DATA AKUN DARI CSV
// ============================================
async function markAccountUsed(index) {
  if (botState.accounts[index]) {
    botState.accounts[index].used = true;
  }
}

// ============================================
// HAPUS TAB SAGEMAKER (SISAKAN 1)
// ============================================
async function closeAllSageMakerTabsExceptOne() {
  try {
    const tabs = await browser.tabs.query({ url: ["*://*.sagemaker.aws/*"] });
    
    if (tabs.length <= 1) {
      console.log("📑 Hanya 1 tab, tidak perlu ditutup");
      return;
    }
    
    const keepTab = tabs[0];
    
    for (let i = 1; i < tabs.length; i++) {
      await browser.tabs.remove(tabs[i].id);
    }
    
    console.log(`🗑️ Closed ${tabs.length - 1} tabs, kept 1 tab`);
    updateStatus(`🗑️ ${tabs.length - 1} tab ditutup`);
    
    await browser.tabs.update(keepTab.id, { active: true });
  } catch (e) {
    console.log("Close tabs error:", e);
  }
}

// ============================================
// FUNGSI KIRIM PESAN KE CONTENT
// ============================================
async function sendToTab(tabId, action, data = {}) {
  try {
    const result = await browser.tabs.sendMessage(tabId, { action, ...data });
    return result;
  } catch (error) {
    console.log(`⚠️ SendToTab error (${action}):`, error.message);
    return null;
  }
}

// ============================================
// AMBIL TAB AKTIF
// ============================================
async function getActiveTab() {
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

// ============================================
// PROSES LOGIN + RUNTIME (TIMEOUT 3 MENIT)
// ============================================
async function processAccount(account, accountIndex) {
  console.log(`\n👤 ===== AKUN #${accountIndex + 1}: ${account.username} =====`);
  updateStatus(`👤 Login: ${account.username}`);
  
  // 1. Hapus cookie + ganti proxy (sudah di set sebelumnya)
  console.log("🍪 Menghapus cookies...");
  await clearSageMakerCookies();
  await sleep(1000);
  
  // 2. Ambil tab aktif
  let tab = await getActiveTab();
  
  if (!tab || !tab.url || !tab.url.includes('sagemaker.aws')) {
    console.log("🌐 Membuka halaman login di tab aktif...");
    tab = await browser.tabs.update(tab.id, { url: 'https://studiolab.sagemaker.aws/' });
    await sleep(5000);
  } else {
    console.log("🔄 Refresh tab aktif...");
    await browser.tabs.reload(tab.id);
    await sleep(5000);
  }
  
  // 3. Klik Login
  console.log("🔐 Mencari tombol Login...");
  updateStatus(`🔐 Klik Login...`);
  await sendToTab(tab.id, 'clickXPath', { xpath: XPATHS.loginButton });
  await sleep(3000);
  
  // 4. Isi Username
  console.log("📝 Mencari field Username...");
  updateStatus(`📝 Isi Username...`);
  await sendToTab(tab.id, 'fillInput', { 
    xpath: XPATHS.username, 
    value: account.username 
  });
  await sleep(1500);
  
  // 5. Isi Password
  console.log("🔒 Mencari field Password...");
  updateStatus(`🔒 Isi Password...`);
  await sendToTab(tab.id, 'fillInput', { 
    xpath: XPATHS.password, 
    value: account.password 
  });
  await sleep(1500);
  
  // 6. Klik Sign In
  console.log("🔐 Mencari tombol Sign In...");
  updateStatus(`🔐 Klik Sign In...`);
  await sendToTab(tab.id, 'clickXPath', { xpath: XPATHS.signInButton });
  
  // 7. Tunggu login + captcha (15 detik)
  console.log("⏳ Tunggu login & captcha (15 detik)...");
  updateStatus(`⏳ Tunggu login & captcha...`);
  await sleep(15000);
  
  // 8. CEK APAKAH LOGIN BERHASIL
  console.log("🔍 Cek apakah login berhasil...");
  const checkLogin = await sendToTab(tab.id, 'checkLoginSuccess');
  console.log("📊 Hasil cek login:", checkLogin);
  
  if (checkLogin && checkLogin.success === false) {
    console.log("❌ Login gagal!");
    updateStatus("❌ Login gagal!");
    return false;
  }
  
  // 9. Tunggu halaman setelah login fully loaded
  console.log("⏳ Tunggu halaman siap (5 detik)...");
  await sleep(5000);
  
  // ==========================================
  // 10. KLIK START RUNTIME
  // ==========================================
  console.log("🚀 Klik Start Runtime...");
  updateStatus(`🚀 Klik Start Runtime...`);
  await sendToTab(tab.id, 'clickXPath', { xpath: XPATHS.startRuntime });
  
  // 11. Tunggu 5 detik (captcha loading)
  console.log("⏳ Tunggu captcha loading (5 detik)...");
  await sleep(5000);
  
  // ==========================================
  // 12. LOOP PENGECEKAN (MAKSIMAL 3 MENIT)
  // ==========================================
  updateStatus(`🔄 Menunggu Runtime...`);
  let runtimeStarted = false;
  let checkCount = 0;
  const MAX_WAIT_TIME = 3 * 60 * 1000; // 3 MENIT
  const startTime = Date.now();
  
  while (!runtimeStarted && botState.active && !botState.stopRequested) {
    checkCount++;
    
    // CEK APAKAH SUDAH 3 MENIT?
    const elapsedTime = Date.now() - startTime;
    console.log(`⏱️ Waktu berlalu: ${(elapsedTime / 60000).toFixed(1)} menit / 3 menit`);
    
    if (elapsedTime >= MAX_WAIT_TIME) {
      console.log(`⏰ Sudah 3 menit! Lanjut ke akun berikutnya`);
      updateStatus(`⏰ Timeout 3 menit! Lanjut...`);
      return false;
    }
    
    // ==========================================
    // CEK CAPTCHA
    // ==========================================
    const captchaResult = await sendToTab(tab.id, 'checkCaptcha');
    console.log(`📊 Hasil cek captcha:`, captchaResult);
    
    if (captchaResult && captchaResult.active === true) {
      console.log("🖼️ CAPTCHA TERDETEKSI! Menunggu captcha selesai...");
      updateStatus(`🖼️ Menunggu captcha...`);
      
      let captchaDone = false;
      let captchaCheckCount = 0;
      
      while (!captchaDone && botState.active && !botState.stopRequested) {
        captchaCheckCount++;
        console.log(`🔍 Cek captcha #${captchaCheckCount}...`);
        
        await sleep(5000);
        
        const captchaCheck = await sendToTab(tab.id, 'checkCaptcha');
        console.log(`📊 Hasil cek captcha #${captchaCheckCount}:`, captchaCheck);
        
        if (captchaCheck && captchaCheck.active === false) {
          console.log("✅ CAPTCHA SELESAI! Melanjutkan...");
          updateStatus("✅ Captcha selesai!");
          captchaDone = true;
          await sleep(2000);
          break;
        }
      }
      
      continue;
    }
    
    // ==========================================
    // CEK TOMBOL START RUNTIME
    // ==========================================
    console.log(`🔍 Cek runtime #${checkCount}...`);
    const result = await sendToTab(tab.id, 'checkRuntimeButton');
    console.log(`📊 Hasil cek runtime #${checkCount}:`, result);
    
    if (result && result.started === true) {
      console.log("✅ Runtime berjalan!");
      updateStatus("✅ Runtime berjalan!");
      runtimeStarted = true;
      updateBadge('✅', '#10b981');
      break;
    }
    
    // ==========================================
    // JIKA BELUM BERUBAH → KLIK LAGI
    // ==========================================
    console.log(`🔄 Runtime belum jalan, klik Start Runtime lagi... (${checkCount})`);
    updateStatus(`🔄 Klik ulang #${checkCount}...`);
    await sendToTab(tab.id, 'clickXPath', { xpath: XPATHS.startRuntime });
    
    await randomDelay();
  }
  
  // Jika runtime tidak berhasil (timeout 3 menit)
  if (!runtimeStarted) {
    console.log("❌ Runtime gagal start (timeout 3 menit)");
    updateStatus("❌ Runtime gagal (timeout)");
    return false;
  }
  
  // ==========================================
  // 13. RUNTIME BERHASIL! KLIK TOMBOL TAMBAHAN / PROJECT
  // ==========================================
  
  // Coba klik tombol extra dulu
  console.log("🖱️ Mencari tombol tambahan...");
  updateStatus(`🖱️ Klik tombol tambahan...`);
  let extraResult = await sendToTab(tab.id, 'clickXPath', { xpath: XPATHS.extraButton });
  
  // Jika gagal, coba klik project
  if (!extraResult || !extraResult.success) {
    console.log("🖱️ Mencoba klik project...");
    updateStatus(`🖱️ Klik project...`);
    await sendToTab(tab.id, 'clickXPath', { xpath: XPATHS.projectButton });
  }
  
  // 14. Jeda 35 detik
  console.log("⏳ Tunggu 35 detik...");
  updateStatus(`⏳ Tunggu 35 detik...`);
  for (let i = 35; i > 0; i--) {
    if (!botState.active || botState.stopRequested) break;
    updateBadge(`${i}s`, '#f59e0b');
    await sleep(1000);
  }
  
  // 15. Tandai akun sudah dipakai
  await markAccountUsed(accountIndex);
  
  // 16. Tutup semua tab (sisakan 1)
  await closeAllSageMakerTabsExceptOne();
  
  console.log(`✅ Akun ${account.username} selesai!`);
  updateStatus(`✅ ${account.username} selesai`);
  
  return true;
}

// ============================================
// MAIN BOT
// ============================================
async function startBot() {
  console.log("🔥 STARTING BOT");
  
  if (botState.active) {
    stopBot();
    await sleep(1000);
  }
  
  botState.active = true;
  botState.stopRequested = false;
  botState.proxyIndex = 0;
  botState.accountIndex = 0;
  
  // Load proxy list
  const data = await browser.storage.local.get('proxyList');
  botState.proxyList = data.proxyList || [...DEFAULT_PROXIES];
  
  if (botState.proxyList.length === 0) {
    updateStatus("❌ No proxies!");
    stopBot();
    return;
  }
  
  // Load accounts
  botState.accounts = await loadAccounts();
  if (botState.accounts.length === 0) {
    updateStatus("❌ No accounts in CSV!");
    stopBot();
    return;
  }
  
  console.log(`📋 ${botState.proxyList.length} proxies, ${botState.accounts.length} accounts`);
  updateStatus(`📋 ${botState.accounts.length} akun ditemukan`);
  
  // Hapus cookie awal
  await clearSageMakerCookies();
  
  try {
    for (let i = 0; i < botState.accounts.length && botState.active && !botState.stopRequested; i++) {
      
      if (botState.accounts[i].used) continue;
      
      // Set proxy untuk akun ini
      const proxy = botState.proxyList[botState.proxyIndex % botState.proxyList.length];
      await setProxy(proxy);
      updateBadge(`P${botState.proxyIndex + 1}`, '#3b82f6');
      
      console.log(`🔄 Memproses akun ${botState.accounts[i].username} dengan proxy #${botState.proxyIndex + 1}`);
      updateStatus(`🔄 ${botState.accounts[i].username} - Proxy ${botState.proxyIndex + 1}/${botState.proxyList.length}`);
      
      // Proses akun
      const success = await processAccount(botState.accounts[i], i);
      
      if (!success) {
        console.log(`⚠️ Akun ${botState.accounts[i].username} gagal (timeout 3 menit)`);
        updateStatus(`⚠️ ${botState.accounts[i].username} gagal (timeout)`);
        // ❌ Jangan tandai used, biar diulang
        // await markAccountUsed(i);  ← HAPUS INI
      }
      
      // Pindah ke proxy berikutnya untuk akun selanjutnya
      botState.proxyIndex++;
      
      // Jeda antar akun
      if (i < botState.accounts.length - 1) {
        console.log(`⏳ Jeda 5 detik sebelum akun berikutnya...`);
        await sleep(5000);
      }
    }
    
    console.log("✅ SEMUA AKUN SELESAI!");
    updateStatus("✅ Semua akun selesai!");
    updateBadge('✅', '#10b981');
    
  } catch (e) {
    if (e.message === 'Stopped by user') {
      console.log("⏹️ Bot stopped by user");
    } else {
      console.error("Error:", e);
    }
  }
  
  stopBot();
}

// ============================================
// STOP BOT
// ============================================
function stopBot() {
  console.log("🛑 Stopping bot...");
  botState.stopRequested = true;
  botState.active = false;
  clearProxy();
  updateBadge('', '');
  updateStatus("⏹️ Stopped");
  browser.runtime.sendMessage({ command: "botStopped" }).catch(() => {});
}

// ============================================
// PROXY HANDLER (Firefox)
// ============================================
browser.proxy.onRequest.addListener((details) => {
  if (botState.activeProxy) {
    const parts = botState.activeProxy.split(':');
    return { type: "http", host: parts[0], port: parseInt(parts[1]) };
  }
  return { type: "direct" };
}, { urls: ["<all_urls>"] });

browser.webRequest.onAuthRequired.addListener((details) => {
  if (details.isProxy && botState.activeProxy) {
    const parts = botState.activeProxy.split(':');
    if (parts.length >= 4) {
      return { authCredentials: { username: parts[2], password: parts[3] } };
    }
  }
  return {};
}, { urls: ["<all_urls>"] }, ["blocking"]);

// ============================================
// MESSAGE HANDLER
// ============================================
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("📩 Message received:", message.command);
  
  if (message.command === "startBot") {
    startBot();
    sendResponse({ status: "started" });
  }
  
  else if (message.command === "stopBot") {
    stopBot();
    sendResponse({ status: "stopped" });
  }
  
  else if (message.command === "getStatus") {
    sendResponse({
      active: botState.active,
      proxyIndex: botState.proxyIndex,
      totalProxies: botState.proxyList.length,
      accountIndex: botState.accountIndex,
      totalAccounts: botState.accounts.length
    });
  }
  
  else if (message.command === "saveProxyList") {
    botState.proxyList = message.proxies;
    browser.storage.local.set({ proxyList: message.proxies });
    sendResponse({ status: "saved" });
  }
  
  else if (message.command === "getProxyList") {
    sendResponse({ proxies: botState.proxyList });
  }
  
  return true;
});

console.log("✅ SAGE BOT READY - Background script persistent!");
